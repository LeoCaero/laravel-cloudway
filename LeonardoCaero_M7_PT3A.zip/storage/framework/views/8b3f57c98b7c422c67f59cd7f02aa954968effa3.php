<!-- Navigation -->
<nav><?php if(Auth::user()): ?>
    <a>Has fet login com a <strong><?php echo e(auth()->user()->name); ?></strong></a>
    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a><br><br>
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
    </form>
    <?php else: ?>
    <a href="<?php echo e(route('login')); ?>">Login</a>
    &nbsp;&nbsp;&nbsp;
    <a href="<?php echo e(route('register')); ?>">Register</a><br><br>
    <?php endif; ?>
    <a href="<?php echo e(route('home')); ?>">Inici</a>
    &nbsp;&nbsp;&nbsp;
    <a href="<?php echo e(route('llibre_list')); ?>">Llibres</a>
    &nbsp;&nbsp;&nbsp;
    <a href="<?php echo e(route('autor_list')); ?>">Autors</a>
    &nbsp;&nbsp;&nbsp;
</nav><?php /**PATH /var/www/html/M07/UF2/PT3A/resources/views/navbar.blade.php ENDPATH**/ ?>