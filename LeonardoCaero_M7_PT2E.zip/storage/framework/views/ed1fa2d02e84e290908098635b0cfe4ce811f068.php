<?php $__env->startSection('title', 'Editar Autor'); ?>

<?php $__env->startSection('stylesheets'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('stylesheets'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1>Edició de <?php echo e($autor->nomCognoms()); ?></h1>
<a href="<?php echo e(route('autor_list')); ?>">&laquo; Torna</a>
<div style="margin-top: 20px">
    <form method="POST" action="<?php echo e(route('autor_edit', ['id' => $autor->id])); ?>"  enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li style="color: red"><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <div>
            <label for="nom">Nom</label>
            <input type="text" name="nom" value="<?php echo e($autor->nom); ?>" />
        </div>
        <div>
            <label for="cognoms">Cognoms</label>
            <input type="text" name="cognoms" value="<?php echo e($autor->cognoms); ?>" />
        </div>
        <?php if($autor->imatge != null): ?>
        <div>
            <label>Imatge actual: </label>
            <a style="font-weight: bold;"><?php echo e($autor->imatge); ?></a>
        </div>
        <div>
        <label for="deleteImage">Eliminar imatge? </label>
        <input type="checkbox" name="deleteImage"/>
        </div>
        <?php endif; ?>
        <div>
            <label for="imatge">Imatge</label>
            <input type="file" name="imatge" value=""/>
        </div>
        <button type="submit">Editar Autor</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/M07/UF2/PT2E/resources/views/autor/edit.blade.php ENDPATH**/ ?>